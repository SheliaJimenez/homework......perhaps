import os
import requests
import hashlib
import bencodepy
from flask import Flask, request, send_file

TRACKER_URL = "http://127.0.0.1:5001"

app = Flask(__name__)

def get_peer_folder(port):
    """ Returns the folder path for a specific peer and ensures it exists. """
    folder = f"peer_{port}"
    if not os.path.exists(folder):
        os.makedirs(folder)
    return folder

def get_info_hash(torrent_file_path):
    """Returns the info_hash and piece list of the torrent file."""
    try:
        # Read the torrent file
        with open(torrent_file_path, 'rb') as f:
            torrent_data = f.read()

        # Decode the torrent data (bencode format)
        decoded_data = bencodepy.decode(torrent_data)

        # Extract the 'info' dictionary
        info_dict = decoded_data[b'info']

        # Generate the SHA1 hash of the 'info' part of the torrent
        info_hash = hashlib.sha1(bencodepy.encode(info_dict)).digest()

        # Extract the pieces in the torrent
        piece_list = info_dict[b'pieces']

        file_name = info_dict[b'name'].decode()  # Decode bytes to string

        return info_hash, file_name
    
    except Exception as e:
        print(f"Error getting info_hash from {torrent_file_path}: {e}")
        return None, []

def get_peers_from_tracker(info_hash):
    """ Requests the tracker for a list of seeders with the given info_hash. """
    try:
        response = requests.get(f"{TRACKER_URL}/get_peers", params={"info_hash": info_hash.hex()})
        if response.status_code == 200:
            peers = response.json().get("peers", [])
            print(*peers)
            return peers
        return []
    except Exception as e:
        print(f"Error retrieving peers from tracker: {e}")
        return []

def download_file(file_name, peer_ip, peer_port, local_port):
    """ Downloads a file from another peer and saves it in this peer's folder. """
    try:
        # Ensure file name uses forward slashes for compatibility

        file_name = file_name.replace("\\", "/")
        absolute_file_path = os.path.abspath(file_name)
        file_url = f"http://{peer_ip}:{peer_port}/{absolute_file_path}"
        absolute_file_path = absolute_file_path.replace("\\", "/")
        file_url = file_url.replace("\\", "/")
        print(f'file_url{file_url}')
        #response = requests.get(absolute_file_path)
        
        # Send the GET request to download the file
        response = requests.get(file_url)
        if response.status_code == 200:
            file_path = os.path.join(get_peer_folder(local_port), file_name)
            with open(file_path, 'wb') as f:
                f.write(response.content)
            print(f"File {file_name} downloaded successfully!")
        else:
            print("Failed to download the file.")
    except Exception as e:
        print(f"⚠️ Error downloading file: {e}")


def request_file(info_hash,file_name):
    """ Requests a file from other peers based on info_hash. """
    print(f"🔍 Fetching peers for info_hash: {info_hash.hex()}...")
    print(info_hash)
    # First, get the list of seeders from the tracker
    peers = get_peers_from_tracker(info_hash)
    if not peers:
        print("No peers found.")
        return
    
    # Second, download the shared file from one of the seeders
    peer_ip = peers[0]['peer_ip']
    peer_port = peers[0]['peer_port']
    #print(*peers)
    print(f"Connecting to peer: {peer_ip}:{peer_port}")

    #要改这个requested file
    # download_file 里的文件路径也要改
    #从哪里搞到一个文件名？

    print("requested_file:")
    print(file_name)
    download_file(file_name, peer_ip, peer_port, 6882)

def run_peer():
    """ Starts the requester's server. """
    port = 6882

    # First, create a folder for the requester
    peer_folder = get_peer_folder(port)
    print(f"Peer running on port {port}, sharing folder: {peer_folder}")

    print(f"Peer is running. You can now request or download the file.")

    # Second, read the torrent file and obtain its info_hash
    torrent_file_path = input("Enter the path to the torrent file for the requested file: ")
    info_hash, file_name = get_info_hash(torrent_file_path)
    
    if info_hash:
        # Finally, request a file based on the info_hash
        print(f"Requested info hash: {info_hash}")

        request_file(info_hash,file_name)
        
    else:
        print("Failed to obtain info_hash.")

if __name__ == "__main__":
    run_peer()
