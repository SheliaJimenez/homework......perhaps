import os
import requests
import threading
import hashlib
import bencodepy
import shutil

from flask import Flask, request, send_file

TRACKER_URL = "http://127.0.0.1:5001"

app = Flask(__name__)

def get_peer_folder(port):
    folder = f"peer_{port}"
    if not os.path.exists(folder):
        os.makedirs(folder)  # This ensures the folder gets created
        print(f"Folder {folder} created.")
    else:
        print(f"Folder {folder} already exists.")
    return folder


def create_torrent(file_name):
    """ Create a .torrent file for the given file. """

    # Check whether the file exists
    if not os.path.isfile(file_name):
        raise FileNotFoundError(f"File {file_name} does not exist.")

    # Prepare torrent metadata ('piece length': 1024 * 1024)
    piece_length = 1024 * 1024
    pieces = []

    file_size = os.path.getsize(file_name)
    with open(file_name, 'rb') as f:
        while chunk := f.read(piece_length):
            pieces.append(hashlib.sha1(chunk).digest())

    torrent_data = {
        b'announce':TRACKER_URL,
        b'info': {
            b'length': file_size,
            b'name': file_name.encode(),
            b'piece length': piece_length,
            b'pieces': b''.join(pieces)
        }
    }

    # Compute the info_hash (SHA1 of the 'info' dictionary)
    info_hash = hashlib.sha1(bencodepy.encode(torrent_data[b'info'])).digest()

    # Create the .torrent file
    torrent_file_name = file_name + '.torrent'
    with open(torrent_file_name, 'wb') as f:
        f.write(bencodepy.encode(torrent_data))
    
    return torrent_file_name, info_hash

def get_info_hash(torrent_file_path):
    """Returns the info_hash and piece list of the torrent file."""
    try:
        # Read the torrent file
        with open(torrent_file_path, 'rb') as f:
            torrent_data = f.read()

        # Decode the torrent data (bencode format)
        decoded_data = bencodepy.decode(torrent_data)

        # Extract the 'info' dictionary
        info_dict = decoded_data[b'info']

        # Generate the SHA1 hash of the 'info' part of the torrent
        info_hash = hashlib.sha1(bencodepy.encode(info_dict)).digest()

        # Extract the pieces in the torrent
        piece_list = info_dict[b'pieces']

        return info_hash, piece_list
    
    except Exception as e:
        print(f"Error getting info_hash from {torrent_file_path}: {e}")
        return None, []

def announce_to_tracker(info_hash, port, shared_files):
    """ Sends an announcement to the tracker with the peer's shared files. """
    params = {
        'info_hash': info_hash.hex(),
        'peer_ip': '127.0.0.1',
        'peer_port': port,
        'shared_files': shared_files
    }

    # Send the announcement to the tracker
    try:
        response = requests.get(f"{TRACKER_URL}/announce", params=params)
        if response.status_code == 200:
            print("Successfully announced to tracker.")
        else:
            print(f"Failed to announce to tracker: {response.status_code}")
    except Exception as e:
        print(f"Failed to announce to tracker: {e}")

@app.route("/download", methods=["GET"])
def download():
    """ Serves a file to other peers upon request. """
    # Get the file name from the query parameters
    file_name = request.args.get("file_name")
    file_name=file_name[1:]
    file_name="C:/Users/BenjaminSo/Desktop/peer_6881/example.txt"
    if not file_name:
        print("No file name provided in the request.")
        return "File name is required.", 400

    # Construct the full file path using the file name and shared folder
    #file_path = os.path.join(get_peer_folder(6881), file_name)
    file_path=file_name
    # Debug print statements to check if the file path is correct
    print(f"Received request for file: {file_name}")
    app.logger.info(f"Constructed file path: {file_path}")

    # Check if the file exists
    if os.path.exists(file_path):
        print(f"File {file_name} found at {file_path}. Returning the file.")
        return send_file(file_path)
    else:
        print(f"File {file_name} not found at {file_path}. Returning 404.")
        return "File not found.", 404



def run_peer():
    """ Starts the seeder's server and announces it to the tracker. """
    port = 6881  # Prompt user for port

    # First create a folder for the seeder, and move the shared file into the folder.
    peer_folder = get_peer_folder(port)
    print(f"Peer running on port {port}, sharing folder: {peer_folder}")

    # Make sure the file is inside the peer folder
    file_name = input("Enter the file name to share: ")
    file_path = os.path.join(peer_folder, file_name)
    
    if not os.path.isfile(file_path):
        print(f"File {file_path} does not exist in the folder.")
        return

    # Then, create a torrent file of the shared file, and share it with the requester directly.
    torrent_file, info_hash = create_torrent(file_path)

    print(f'file path {file_path}')
    # Finally, send an announcement to register the shared files with the tracker.
    announce_to_tracker(info_hash, port, [file_path])

    # Start Flask server for file sharing
    app.run(host="0.0.0.0", port=port, debug=True, use_reloader=False)
    #just for testing
    print(f"Info hash: {info_hash.hex()}")


    print(f"Peer is running. You can now request or download the file.")


if __name__ == "__main__":
    run_peer()
