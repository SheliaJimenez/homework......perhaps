from flask import Flask, request, jsonify
#import hashlib
#import json

app = Flask(__name__)

# This will act as our in-memory tracker database
TRACKER_DB = {}

@app.route("/announce", methods=["GET", "POST"])
def announce():
    """ Handle announcements from seeders. """
    try:
        params = request.args if request.method == 'GET' else request.json
        info_hash = bytes.fromhex(params['info_hash'])
        peer_ip = params['peer_ip']
        peer_port = params['peer_port']
        shared_files = params['shared_files']
        # for testing
        print(f"Params: {params}")
        ###
        if info_hash not in TRACKER_DB:
            TRACKER_DB[info_hash] = []

        TRACKER_DB[info_hash].append({"peer_ip": peer_ip, "peer_port": peer_port, "shared_files": shared_files})

        print(*TRACKER_DB[info_hash])
        return jsonify({"status": "success"}), 200
    except Exception as e:
        print(f"Error processing announce: {e}")
        return jsonify({"status": "error", "message": str(e)}), 400

@app.route("/get_peers", methods=["GET"])
def get_seeders():
    """ Get the list of seeders for a given info_hash. """
    info_hash = bytes.fromhex(request.args['info_hash'])
    seeders = TRACKER_DB.get(info_hash, [])
    return jsonify({"peers": [{"peer_ip": s["peer_ip"], "peer_port": s["peer_port"]} for s in seeders]})

@app.route("/show_tracker_data", methods=["GET"])
def show_tracker_data():
    """ Show the entire tracker data. """
    return jsonify(TRACKER_DB)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)
